storage_directory = "./ddb_storage"
use_compression = False
pretty_json_files = True